from astropy.io import fits

def open_file():
    print("opening file")
    return fits.open('astro-td-2024/data/masterdark.fits')
